import React from "react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Digital Dominance",
  description:
    "Downloadable tools built by a Canadian oil and gas worker, for the Canadian oil and gas industry.",
};

const RED = "#B11226";
const RED_HOVER = "#D32F2F";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          fontFamily:
            "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
          backgroundColor: "#ffffff",
          color: "#111",
        }}
      >
        <style>{`
          a {
            color: ${RED};
            text-decoration: none;
            font-weight: 500;
          }

          a:hover {
            opacity: 0.9;
          }

          header {
            background: linear-gradient(90deg, ${RED}, #7a0c1a);
            color: white;
            box-shadow: 0 2px 12px rgba(0,0,0,0.35);
          }

          header a {
            color: white;
          }

          .download-btn {
            display: inline-block;
            margin-top: 1rem;
            background: ${RED};
            color: white;
            padding: 0.85rem 1.4rem;
            border-radius: 6px;
            font-weight: 600;
            letter-spacing: 0.02em;
            border: 1px solid #7a0c1a;
            transition: all 0.25s ease;
            box-shadow: 0 0 0 rgba(177,18,38,0);
          }

          .download-btn:hover {
            background: ${RED_HOVER};
            box-shadow: 0 0 16px rgba(177,18,38,0.65);
            transform: translateY(-2px);
          }

          .tool-card {
            padding: 2rem;
            border: 1px solid #ddd;
            border-left: 4px solid ${RED};
            border-radius: 6px;
            transition: box-shadow 0.25s ease, transform 0.25s ease;
          }

          .tool-card:hover {
            box-shadow: 0 0 20px rgba(177,18,38,0.35);
            transform: translateY(-2px);
          }

          .tool-divider {
            border-top: 1px solid ${RED};
            margin: 2.5rem 0;
            opacity: 0.6;
          }

          .canada {
            font-size: 0.85rem;
            opacity: 0.85;
          }

          footer {
            background: #111;
            color: #aaa;
            border-top: 4px solid ${RED};
          }

          @media (prefers-color-scheme: dark) {
            body {
              background-color: #0e0e0e;
              color: #f5f5f5;
            }

            .tool-card {
              background-color: #141414;
              border-color: #222;
            }

            footer {
              background-color: #0a0a0a;
              color: #888;
            }
          }
        `}</style>

        {/* HEADER */}
        <header
          style={{
            padding: "1.75rem 3rem",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div>
            <div
              style={{
                fontSize: "1.25rem",
                letterSpacing: "0.04em",
                textTransform: "uppercase",
                fontWeight: 700,
              }}
            >
              Digital Dominance
            </div>

            <div
              style={{
                fontSize: "0.85rem",
                marginTop: "0.25rem",
                opacity: 0.9,
              }}
            >
              Straight goods. No bullshit. Built to work.
            </div>
          </div>

          <nav style={{ display: "flex", gap: "2rem" }}>
            <a href="/">Home</a>
            <a href="/tools">Tools</a>
            <a href="/about">About</a>
          </nav>
        </header>

        {/* CONTENT */}
        <main>{children}</main>

        {/* FOOTER */}
        <footer
          style={{
            marginTop: "6rem",
            padding: "3rem",
            fontSize: "0.9rem",
            textAlign: "center",
          }}
        >
          <div className="canada">🇨🇦 Built in Canada</div>
          <div style={{ marginTop: "0.5rem" }}>
            Built by a Canadian oil and gas worker, for the Canadian oil and gas
            industry.
          </div>
          <div style={{ marginTop: "0.75rem" }}>
            © {new Date().getFullYear()} Digital Dominance
          </div>
        </footer>
      </body>
    </html>
  );
}
