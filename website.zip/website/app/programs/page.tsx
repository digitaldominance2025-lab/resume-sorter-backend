export default function Programs() {
  return (
    <main style={{ padding: "4rem" }}>
      <h1>Programs</h1>
      <p>Our available programs will appear here.</p>
    </main>
  );
}
