export default function AboutPage() {
  return (
    <main
      style={{
        padding: "4rem",
        maxWidth: "900px",
        margin: "0 auto",
        lineHeight: 1.6,
      }}
    >
      <h1>About</h1>

      <p>
        Digital Dominance was built by a Canadian oil and gas worker who was fed
        up with bloated software, useless tools, and products that look good on
        paper but fail in the field.
      </p>

      <p>
        This site exists for one reason: to provide{" "}
        <strong>straight goods that work</strong>.
      </p>

      <div className="tool-divider" />

      <p>
        Every tool published here is designed with real-world constraints in
        mind — limited connectivity, tight timelines, and people who just want
        something that does its job without getting in the way.
      </p>

      <p>
        No subscriptions. No fluff. No bullshit.
      </p>

      <p className="canada">
        🇨🇦 Built in Canada, for the Canadian oil and gas industry.
      </p>
    </main>
  );
}
