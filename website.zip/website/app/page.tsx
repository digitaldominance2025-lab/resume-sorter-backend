export default function Home() {
  return (
    <main
      style={{
        padding: "5rem 3rem",
        maxWidth: "1100px",
        margin: "0 auto",
      }}
    >
      <h1 style={{ fontSize: "3.2rem", letterSpacing: "-0.03em" }}>
        Digital Dominance
      </h1>

      <p
        style={{
          maxWidth: "720px",
          fontSize: "1.15rem",
          lineHeight: 1.6,
          marginTop: "1.5rem",
          color: "#444",
        }}
      >
        We build programs, internal tools, and AI-powered applications designed
        to streamline hiring, evaluation, and operational workflows.
      </p>

      {/* Primary CTA */}
      <div style={{ marginTop: "2.5rem" }}>
        <a
          href="/programs"
          style={{
            padding: "0.85rem 1.75rem",
            backgroundColor: "#111",
            color: "#fff",
            textDecoration: "none",
            borderRadius: "6px",
            fontWeight: 500,
          }}
        >
          View Programs
        </a>
      </div>

      {/* Featured Tool */}
      <section
        style={{
          marginTop: "4rem",
          padding: "2.5rem",
          borderRadius: "10px",
          background: "linear-gradient(135deg, #f8f8f8, #f2f2f2)",
          border: "1px solid #eaeaea",
        }}
      >
        <h2 style={{ fontSize: "1.8rem" }}>
          Resume Sorting Tool
        </h2>

        <p
          style={{
            maxWidth: "640px",
            marginTop: "1rem",
            lineHeight: 1.6,
            color: "#444",
          }}
        >
          A downloadable AI-powered application that quickly evaluates and
          organizes resumes, helping teams focus on top candidates faster.
        </p>
      </section>

      {/* About Section */}
      <section
        style={{
          marginTop: "5rem",
          paddingTop: "3rem",
          borderTop: "1px solid #eaeaea",
        }}
      >
        <h2 style={{ fontSize: "1.4rem" }}>About</h2>
        <p
          style={{
            marginTop: "1rem",
            maxWidth: "700px",
            lineHeight: 1.6,
            color: "#444",
            fontSize: "1rem",
          }}
        >
          Built by a Canadian oil and gas worker, for the Canadian oil and gas
          industry.
        </p>
      </section>
    </main>
  );
}
