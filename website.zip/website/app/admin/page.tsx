export default function Admin() {
  return (
    <main style={{ padding: "4rem" }}>
      <h1>Admin</h1>
      <p>Admin dashboard coming soon.</p>
    </main>
  );
}
