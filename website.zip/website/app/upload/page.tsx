export default function Upload() {
  return (
    <main style={{ padding: "4rem" }}>
      <h1>Resume Upload</h1>
      <p>Resume upload functionality coming soon.</p>
    </main>
  );
}
