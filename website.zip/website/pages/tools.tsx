export default function Tools() {
  return (
    <main
      style={{
        padding: "5rem 3rem",
        maxWidth: "1100px",
        margin: "0 auto",
        fontFamily:
          "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      }}
    >
      <h1 style={{ fontSize: "2.8rem" }}>Tools</h1>

      <p style={{ maxWidth: "700px", marginTop: "1rem", color: "#444" }}>
        Downloadable productivity and hiring tools. Built to run locally. No
        accounts. No data collection.
      </p>

      <section
        style={{
          marginTop: "3rem",
          padding: "2.5rem",
          border: "1px solid #eaeaea",
          borderRadius: "12px",
          backgroundColor: "#fafafa",
        }}
      >
        <h2>Resume Sorting Tool</h2>

        <p style={{ maxWidth: "640px", marginTop: "0.75rem", color: "#444" }}>
          A downloadable application that analyzes and organizes resumes to help
          teams evaluate candidates faster and more consistently.
        </p>

        <button
          disabled
          style={{
            marginTop: "1.25rem",
            padding: "0.75rem 1.5rem",
            borderRadius: "6px",
            border: "1px solid #ccc",
            backgroundColor: "#eaeaea",
            cursor: "not-allowed",
          }}
        >
          Download (Coming Soon)
        </button>
      </section>
    </main>
  );
}
